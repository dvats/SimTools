# SimTools: Variability assessment for simulation methods in R

Leadership:
[Dootika Vats](http://dvats.github.io/), [James Flegal](https://faculty.ucr.edu/~jflegal/), [Galin Jones](http://users.stat.umn.edu/~galin/)

Contributors:
Gunjan Jalori

The development of this package has begun. Updates will be described in this README. For communication regarding issues in the code and other suggestions, maybe we can try and use the GitHub Issues interface.

